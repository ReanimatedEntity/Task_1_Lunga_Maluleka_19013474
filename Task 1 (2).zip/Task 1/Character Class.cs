﻿using System;
using System.Runtime.CompilerServices;

public class Character Class
{
	abstract class Character:Tile 	
{
		protected int HP;
        protected int MaxHP;
        protected int Damage;
        protected int Vision_Tile;
        string Coords

    public enum Movement
    {
        Nothing, Up, Down, Left, Right
    }
	
    public int HP { get => HP; set => HP = value; }

    public int MaxHP { get => MaxHP; set => MaxHP = value; }

    public int Damage { get => Damage; set => Damage = value; }

    public int Vision_Tile { get => Vision_Tile; set => Vision_Tile = value; }

    public Character(int X, int Y) : base (X, Y)

        string[] Coords = new string[4] { "North", "South", "East", "West" };
}


public Movement Move(Movement move = 0)
{
    return 0;
}
public void Move(Movement move)
{
    switch (move)
    {
        case Movement.Nothing:
            y = y + 0;
            break;
        case Movement.Up:
            y = y + 1;
            break;
        case Movement.Down:
            y = y - 1;
            break;
        case Movement.Left:
            y = y - 1;
            break;
        case Movement.Right:
            y = y - 1;
            break;
    }
}

public Movement ReturnMove(Movement move = 0)
{
    return 0;
}

}
