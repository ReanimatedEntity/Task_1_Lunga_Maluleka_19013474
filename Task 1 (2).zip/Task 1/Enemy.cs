﻿using System;

public class Class1
{
	class Character : Enemy
	{
		public class Hero(int y, int x) : base (y, x)
	}
}
}
