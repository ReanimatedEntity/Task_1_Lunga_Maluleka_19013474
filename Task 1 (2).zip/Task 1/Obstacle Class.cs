﻿using System;

public class Class1
{
	class Obstacle : Tile
	{
		public Obstacle (int X, int Y) : base(X, Y)
	}
}
