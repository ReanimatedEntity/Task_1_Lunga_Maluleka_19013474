﻿using System;

public class Class1
{
	class EmptyTile : Tile
	{
		public EmptyTile(int X, int Y) : base(X, Y)
	}
}
